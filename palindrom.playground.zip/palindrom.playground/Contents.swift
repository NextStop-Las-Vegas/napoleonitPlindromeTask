import UIKit

func isNumberPalindrome(_ x: Int) -> Bool {
var currentNumber = x
var reverseNumber = 0
while currentNumber > 0 {
    let fixNumber = currentNumber % 10
    reverseNumber = reverseNumber * 10 + fixNumber
    currentNumber = currentNumber / 10
}
return x == reverseNumber
}

isNumberPalindrome(123456789987654321)
